a = 10.567
print(round(a,2))
a = 10.56
print(round(a,2))
a = 10.50
print(round(a,2))
a = 10.5
print(round(a,2))
